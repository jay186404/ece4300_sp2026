`timescale 1ns / 1ps

module aes_bench_top (
    input  wire clk100mhz,
    input  wire rst,
    input  wire start,
    input  wire enc_dec,   // 1 = encrypt, 0 = decrypt
    output wire [15:0] leds
);

    localparam [127:0] KEY        = 128'h000102030405060708090A0B0C0D0E0F;
    localparam [127:0] PLAINTEXT  = 128'h00112233445566778899AABBCCDDEEFF;
    localparam [127:0] CIPHERTEXT = 128'h69C4E0D86A7B0430D8CDB78070B4C55A;

    reg         start_d;
    wire        start_pulse;
    reg [31:0]  cycle_counter;
    reg [31:0]  latency_cycles;
    wire [127:0] data_out;

    wire busy;
    wire done;

    wire [127:0] test_data = enc_dec ? PLAINTEXT : CIPHERTEXT;

    aes128_core u_core (
        .clk      (clk100mhz),
        .rst      (rst),
        .start    (start_pulse),
        .enc_dec  (enc_dec),
        .key      (KEY),
        .data_in  (test_data),
        .data_out (data_out),
        .busy     (busy),
        .done     (done)
    );

    always @(posedge clk100mhz) begin
        if (rst) begin
            start_d        <= 1'b0;
            cycle_counter  <= 32'd0;
            latency_cycles <= 32'd0;
        end else begin
            start_d <= start;

            if (start_pulse) begin
                cycle_counter <= 32'd0;
            end else if (busy) begin
                cycle_counter <= cycle_counter + 1'b1;
            end

            if (done)
                latency_cycles <= cycle_counter;
        end
    end

    assign start_pulse = start & ~start_d;

    wire pass = enc_dec ? (data_out == CIPHERTEXT) : (data_out == PLAINTEXT);

    // leds[15] = busy
    // leds[14] = done
    // leds[13] = pass
    // leds[12:0] = latency
    assign leds = {busy, done, pass, latency_cycles[12:0]};

endmodule